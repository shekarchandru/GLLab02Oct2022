package com.gl.stmgmt.DebnathProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.gl.stmgmt.DebnathProj.controller","com.gl.stmgmt.DebnathProj"})
public class DebnathProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(DebnathProjApplication.class, args);
	}

}
