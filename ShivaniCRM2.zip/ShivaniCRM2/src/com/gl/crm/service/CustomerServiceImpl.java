package com.gl.crm.service;
//import javax.transaction.Transaction;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.Transaction;
import javax.websocket.Session;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.Expression;
import org.springframework.stereotype.Repository;

import com.gl.crm.entity.Customer;



@Transactional
@EnableTransactionManagement
@Repository
public class CustomerServiceImpl implements CustomerService {

	private org.hibernate.Session session;

	@Autowired
	CustomerServiceImpl(SessionFactory sessionFactory){
		try {
			session = sessionFactory.getCurrentSession();
		}catch(HibernateException e) {
			session =sessionFactory.openSession();
		}
	}

	@Transactional
	public List<Customer> findAll(){
	//	Transaction tx = session.beginTransaction();

		List<Customer> customer=session.createQuery("from Customer").list();

	//	tx.commit();

		return customer;

	}

/*	@Transactional
	public Customer findById(int id) {

		Customer customer = new Customer();
	//	Transaction tx = session.beginTransaction();

		customer = session.get(Customer.class, id);

	//	tx.commit();

		return customer;
	}*/

	@Transactional
	public void save(Customer theCustomer) {

	//	Transaction tx = (Transaction)session.beginTransaction();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(theCustomer);
		tx.commit();
	}

	@Transactional
	public void deleteById(int id) {

		Transaction tx =session.beginTransaction();

		Customer customer = session.get(Customer.class, id);

		session.delete(customer);

		tx.commit();
	}

	@Override
	public Customer findbyId(int theId) {
		// TODO Auto-generated method stub
		Customer customer = new Customer();
		//	Transaction tx = session.beginTransaction();

			customer = session.get(Customer.class, theId);

		//	tx.commit();

			return customer;
	}

	

}




