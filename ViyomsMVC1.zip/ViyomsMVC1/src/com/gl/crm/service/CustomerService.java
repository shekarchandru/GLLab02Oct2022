package com.gl.crm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gl.crm.entity.Customer;



//@Service
	public interface CustomerService {
	
	public String getData1();
	
	public List<Customer>findAll();

	 public void save(Customer theCustomer);
	 public void deleteById(int theId);

	public Customer findById(int theId);

}
