package com.gl.library.SpringSwaggerDemo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gl.library.SpringSwaggerDemo.model.GreatLearning;



@SpringBootApplication
public class SpringSwaggerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSwaggerDemoApplication.class, args);
		System.out.println("Hello spring boot");
		System.out.println("Hello Dev-tools");
	}
	public void run(String... args) throws Exception {

		GreatLearning greatLearning = new GreatLearning();
		greatLearning.setCourseName("Designing Microservices with Spring Boot");
		greatLearning.setCourseType("Information Technology");
		greatLearning.setInstrutorName("Arun Joseph Mathew");

		System.out.println("Great Learning " + greatLearning); 
	}
}
