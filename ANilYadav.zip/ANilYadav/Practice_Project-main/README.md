# Practice_Project
#Above is the mysql data I have inserted in required tables.
