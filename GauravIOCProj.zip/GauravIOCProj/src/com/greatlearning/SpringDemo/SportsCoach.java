package com.greatlearning.SpringDemo;

public interface SportsCoach {
	public String GetTrainingScehdule();
	public String GetAdvice();

}
