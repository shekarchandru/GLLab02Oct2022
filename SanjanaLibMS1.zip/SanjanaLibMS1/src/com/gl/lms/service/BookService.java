package com.gl.lms.service;

import java.util.List;

import com.gl.lms.entity.Book;



public interface BookService {
	// We need to code the interface
	// to achieve abstraction
	public List<Book> findAll();
}
