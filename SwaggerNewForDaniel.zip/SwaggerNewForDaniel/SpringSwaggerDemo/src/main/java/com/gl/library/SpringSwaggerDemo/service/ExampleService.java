package com.gl.library.SpringSwaggerDemo.service;

import com.gl.library.SpringSwaggerDemo.model.GreatLearning;

public interface ExampleService {

	GreatLearning get();

	GreatLearning customInfo(String courseName, String courseType, String instructorName);

}