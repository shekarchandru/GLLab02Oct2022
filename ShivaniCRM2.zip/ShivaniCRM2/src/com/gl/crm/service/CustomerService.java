package com.gl.crm.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gl.crm.entity.Customer;


@Service
public interface CustomerService {

	public Customer findbyId(int theId);

	public void deleteById(int theId);

	public void save( Customer thestudent);

	public  List<Customer> findAll();






}


