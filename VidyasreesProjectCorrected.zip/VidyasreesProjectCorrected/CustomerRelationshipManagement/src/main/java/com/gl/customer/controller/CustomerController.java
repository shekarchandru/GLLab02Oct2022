package com.gl.customer.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.customer.entity.Customer;
import com.gl.customer.service.CustomerService;


@Controller
@RequestMapping("/")
public class CustomerController {
	
	//@Autowired @Qualifier("customerService")
	@Autowired
//	@Lazy
	CustomerService customerService;
	
	@RequestMapping("/clist")	
	public String HomePage()
	{
		return "redirect:/list";
	}
	
	@RequestMapping("/list")
	public String getAllBooks(Model model) {
		List <Customer> res = customerService.findAll();
		model.addAttribute("customerModel", res);
		return "Home";
	}
	
	@RequestMapping("/add")
	public String addCustomer(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer", customer);
		return "AddNewCustomer";
	}
	
	@RequestMapping("/update")
	public String updateCustomer(@RequestParam("id") int id,Model model) {
		
		Customer customer=customerService.findById(id);
		model.addAttribute("customer", customer);
	
		return "AddNewCustomer";
	}
	
	@RequestMapping("/delete")
	public String deleteBook(@RequestParam("id") int id) {
		customerService.deleteById(id);
		Customer customer=new Customer();
		System.out.println("Deleted Customer Id"+ customer.getId());
		return "redirect:/list";
	}
	
	/*
	 * @RequestMapping(value="/redirect", method = RequestMethod.GET) public String
	 * redirect() { return "redirect:AddNewCustomerPage"; }
	 * 
	 * @RequestMapping(value="/AddNewCustomerPage", method=RequestMethod.GET) public
	 * String AddNewCustomerPage(Model model) { Customer customer=new Customer();
	 * 
	 * model.addAttribute("Customer", customer);
	 * 
	 * return "Home"; }
	 */
		
	 @PostMapping("/save") 
	 public String saveBook(@RequestParam("id") int id, @RequestParam("fname") String fname,
		  @RequestParam("lname") String lname, @RequestParam("email") String email) 
	 {
		  System.out.println(id); 
		  Customer customer;
		  if (id != 0) 
		  { 
			 customer=customerService.findById(id);
			 customer.setFirstName(fname);
			 customer.setLastName(lname);
			 customer.setEmail(email);
		  
		  } 
		  else 
			  customer=new Customer(fname, lname, email);
		  
		  customerService.save(customer);
		  return "redirect:/clist";
			 
		
		  
	 }
		 
	 
}