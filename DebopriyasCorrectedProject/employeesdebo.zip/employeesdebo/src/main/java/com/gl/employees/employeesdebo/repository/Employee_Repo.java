package com.gl.employees.employeesdebo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.gl.employees.employeesdebo.entity.Employee;



@Repository
@EnableJpaRepositories
//CHANGED
//public interface Employee_Repo extends JpaRepository<Employee,Integer>
public interface Employee_Repo extends JpaRepository<Employee,Long> {

	
}
