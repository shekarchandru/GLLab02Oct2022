package com.greatlearning.studentregistrations.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.studentregistrations.dao.StudentServiceImplementation;
import com.greatlearning.studentregistrations.entity.Student;
import com.greatlearning.studentregistrations.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentService studentServ;
	
	@RequestMapping("/list")
	public String listStudents(Model model1) {

		List<Student> student1 = studentServ.findAll();
		model1.addAttribute("students", student1);

		return "list-Students";
	}

	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model model2) {

		Student student2 = new Student();

		model2.addAttribute("Student", student2);

		return "Student-form";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("studentId") int id, Model model3) {
		Student student3 = studentServ.findById(id);

		model3.addAttribute("Student", student3);

		return "Student-form";
	}

	@PostMapping("/save")
	public String saveBook(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("department") String department, @RequestParam("country") String country) {

		Student student4;

		// update existing record case
		if (id != 0) {
			// fetching record based on id and save it after updating same record
			// get the book based on id from the database
			student4 = studentServ.findById(id);

			student4.setName(name);
			student4.setDepartment(department);
			student4.setCountry(country);
		}
		// add new record case
		else {
			student4 = new Student(name, department, country);
		}

		// save the book
		studentServ.save(student4);

		return "redirect:/students/list";

	}

	@RequestMapping("/delete")
	public String deleteBooks(@RequestParam("studentId") int id) {
		// delete the book
		studentServ.deleteById(id);

		return "redirect:/students/list";
	}

}
