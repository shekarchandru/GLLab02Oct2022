package com.greatlearning.SpringDemo;

import org.springframework.stereotype.Component;

@Component
public interface ExpertAdvice {
	public String GetExpertAdvice();

}
