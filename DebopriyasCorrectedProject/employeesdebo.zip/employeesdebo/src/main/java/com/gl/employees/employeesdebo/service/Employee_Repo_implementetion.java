package com.gl.employees.employeesdebo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.employees.employeesdebo.entity.Employee;
import com.gl.employees.employeesdebo.repository.Employee_Repo;



@Service
public class Employee_Repo_implementetion {

	@Autowired
	Employee_Repo employee_Repo;
	
	public  List<Employee> FeatchAllData() {
		
		return this.employee_Repo.findAll();
	}
	
	public Optional<Employee> FindById(Long id) {
		
		return this.employee_Repo.findById(id);
	}
	
	public Employee SaveEmployee(Employee employee) {
		
		return this.employee_Repo.saveAndFlush(employee);
	}
	
	public  void DeleteEmplyee(Employee employee) {
		this.employee_Repo.delete(employee);
	}
}
