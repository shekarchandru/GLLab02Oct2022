package com.gl.employees.employeesdebo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.gl.employees.employeesdebo","com.gl.employees.employeesdebo.config","com.gl.employees.employeesdebo.controller","com.gl.employees.employeesdebo.entity","com.gl.employees.employeesdebo.service","com.gl.employees.employeesdebo.repository"})
public class EmployeesdeboApplication {

	public static void main(String[] args) {
		System.out.println("App is Ok");
		SpringApplication.run(EmployeesdeboApplication.class, args);
	}

}
