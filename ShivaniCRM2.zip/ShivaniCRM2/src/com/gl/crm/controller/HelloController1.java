package com.gl.crm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hellos")
public class HelloController1 {

	@RequestMapping("/greeting")
	public String showMainPage()
	{
		return "demo";
	}
}
