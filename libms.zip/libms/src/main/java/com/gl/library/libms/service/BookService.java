package com.gl.library.libms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gl.library.libms.entity.Book;


@Service
public interface BookService {

	public List<Book> getAllBooks();
	public void save(Book book);
	public void deleteById(int id);
	public List<Book> search(String bookName, String author);
	public Book getBookById(int id);
	
}
