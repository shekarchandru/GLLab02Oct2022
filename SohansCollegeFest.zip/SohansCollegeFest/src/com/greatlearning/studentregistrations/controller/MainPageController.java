package com.greatlearning.studentregistrations.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class MainPageController {

	@RequestMapping("/hello")
	public String showMainPage() {
		
		return "main-Page";
	}
}
