insert into library values(1,'kannad books, english books','literature books');
insert into library values(2,'sun ,moon,saturn','space library');