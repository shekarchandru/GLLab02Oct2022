package com.greatlearning.springbootEmployeeManagementDesign;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeManagementDesignApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeManagementDesignApplication.class, args);
	}

}
