package com.gl.library.libms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.library.libms.entity.Book;



public interface BookRepository extends JpaRepository<Book, Integer>{
	public List<Book> findByBookNameContainsAndAuthorContainsAllIgnoreCase(String bookname,String author);
	

}
