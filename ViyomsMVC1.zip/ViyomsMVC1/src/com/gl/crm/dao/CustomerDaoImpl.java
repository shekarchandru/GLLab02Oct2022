package com.gl.crm.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.gl.crm.entity.Customer;


@Repository
@EnableTransactionManagement
public class CustomerDaoImpl implements CustomerDao {

	@Override
	public String getData() {
		// TODO Auto-generated method stub
		return "Hello World";
	}

	
	@Autowired
	private SessionFactory sessionFactory;
	Session currentSession ;
	
	@Override
	@Transactional
	public List <Customer> getCustomers() {
		// TODO Auto-generated method stub
		// get the current hibernate session
				currentSession = sessionFactory.getCurrentSession();
						
				// create a query  ... sort by last name
				Query<Customer> theQuery = 
						currentSession.createQuery("from Customer order by last_Name",
													Customer.class);
				
				// execute query and get result list
				List<Customer> customers = theQuery.getResultList();
						
				// return the results		
				return customers;
	}

	@Override
	@Transactional
	public void saveCustomer(Customer theCustomer) {
		// TODO Auto-generated method stub
		// get current hibernate session
				currentSession = sessionFactory.getCurrentSession();
				
				// save/upate the customer ... finally LOL
				currentSession.saveOrUpdate(theCustomer);
		
	}

	@Override
	@Transactional
	public Customer getCustomer(int theId) {
		// TODO Auto-generated method stub
		// get the current hibernate session
		currentSession = sessionFactory.getCurrentSession();
		
		// now retrieve/read from database using the primary key
		Customer theCustomer = currentSession.get(Customer.class, theId);
		System.out.println(theCustomer);
		return theCustomer;
	}

	@Override
	@Transactional
	public void deleteCustomer(int theId) {
		// get the current hibernate session
				currentSession = sessionFactory.getCurrentSession();
				
				// delete object with primary key
				Query theQuery = 
						currentSession.createQuery("delete from Customer where id=:customerId");
				theQuery.setParameter("customerId", theId);
				
				theQuery.executeUpdate();		
		
	}
}
