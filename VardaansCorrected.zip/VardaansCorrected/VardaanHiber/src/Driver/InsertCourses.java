package Driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.Course;
import Entity.Teacher;
import Entity.TeacherDetails;

public class InsertCourses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//create session factory
				SessionFactory factory=new Configuration()
						                   .configure("Hibernate.cfg.xml")
						                   .addAnnotatedClass(Teacher.class)
						                   .addAnnotatedClass(TeacherDetails.class)
						                   .addAnnotatedClass(Course.class)
						                   .buildSessionFactory();
				
				//create session
				Session session=factory.getCurrentSession();
				try
				{
					session.beginTransaction();
					int theId = 1;
					Teacher teacher = session.get(Teacher.class, theId);
					Course course1 = new Course("PHP");
					Course course2 = new Course("VS.Net");
					teacher.add(course1);
					teacher.add(course2);
					//session.save(teacher);
				/*	*/
					session.save(course1);
					session.save(course2);
					 
					session.getTransaction().commit();
					System.out.println("Completed Successfully");
				}
				finally {
					factory.close();
					session.close();
				}
				

	}

}
