package com.greatLearning.Library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLibraryDesignApplicationTests {

	@Test
	void contextLoads() {
	}

}
