package com.greatlearning.springMVCdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class HelloController {
	
  @RequestMapping("/greet")
  public String sayHello() {
	  return "mainmenu";
  }
}
