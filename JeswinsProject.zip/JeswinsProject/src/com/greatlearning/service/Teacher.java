package com.greatlearning.service;

import org.springframework.stereotype.Component;

@Component
public interface Teacher {

	public String gethomework();
	public String getExamTip();
}
