package com.gl.employees.employeesdebo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.gl.employees.employeesdebo.config.MyUserDetails;
import com.gl.employees.employeesdebo.entity.User;
import com.gl.employees.employeesdebo.repository.UserRepository;



public class UserDetailsServiceImpl implements UserDetailsService{
	
	@Autowired
	UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user = userRepository.getUserByUserName(username);
		System.out.println(user);
		if(user == null)
		{
			throw new UsernameNotFoundException("Could not find the User");
		}
		return new MyUserDetails(user);
	}

}
