package com.greatlearning.library.model.jdbc_demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BookDAO {

	public void getAllBooks(Statement stmt) throws Exception{
		String str = "select title, price,qty from books";
		ResultSet rs = stmt.executeQuery(str);
		int rowCounter=0;
		while (rs.next()) {
			String title = rs.getString("title");
			double price = rs.getDouble("price");
			int qty = rs.getInt("qty");
			
			System.out.println("The Data =");
			System.out.println("title = "+title);
			System.out.println("price = "+price);
			System.out.println("Qty "+qty);
			++rowCounter;
		} // added closing Curlybrace
	
		}
		
		
		public void saveData(Connection conn)throws Exception {
				String str = "insert into books(id,title,author)values(?,?,?)";
				PreparedStatement psts = conn.prepareStatement(str); // CHANGED spelling
				psts.setInt(1, 5007);
				psts.setString(2, "Title50");
				psts.setString(3,  "Raman");
				int row = psts.executeUpdate();
    
    
		}
		
		public void deletebook(Statement stmt) {
		String sql = "delete from books where id >=3000 and id < 4000";
		//CHANGED BELOW
		int counter=0;// HANDLED EXCEPTION
		try {
			counter = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("the Delete recorded:- "+counter);
		
	}
		// CHANGED: Corrected spelling from Exeception to Exception
		public void updateBook(Statement stmt)throws Exception { 
			String sql = "update books set price = price*1.07 where id = 1001";
			//CHANGED : stmt.executeUpdate();
			int counter = stmt.executeUpdate(sql);
			System.err.println(counter);
			//CHANGED: from System.err.printIn
 
		}
	
}

