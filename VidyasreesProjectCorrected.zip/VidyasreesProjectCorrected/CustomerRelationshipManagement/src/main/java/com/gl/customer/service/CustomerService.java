package com.gl.customer.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.gl.customer.entity.Customer;

@Component("customerService")
public interface CustomerService {
	
	public List<Customer> findAll();
	public Customer findById(int id);
	public void save(Customer customer);
	public void deleteById(int id);

}
