package com.gl.lms.service;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.gl.lms.entity.Book;






@Repository
public class BookServiceImpl implements BookService {
	
	//To create a single session for each or every request 
	/*private Session session;
		
	
		BookServiceImpl (SessionFactory sessionFactory){
			
		}*/
	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
