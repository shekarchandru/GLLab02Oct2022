package com.greatlearning.studentregistrations.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.studentregistrations.entity.Student;
import com.greatlearning.studentregistrations.service.StudentService;

@Repository
public class StudentServiceImplementation implements StudentService {

	private Session session;

	@Autowired
	public StudentServiceImplementation(SessionFactory sessionFactory) {
		try {
			session = sessionFactory.getCurrentSession();
		} catch (HibernateException e) {
			session = sessionFactory.openSession();
		}
	}

	@Transactional
	public List<Student> findAll() {
		Transaction tx = session.beginTransaction();

		List<Student> students = session.createQuery("from Student").list();

		tx.commit();
		return students;
	}

	@Transactional
	public Student findById(int id) {
		Transaction tx = session.beginTransaction();

		// get student record from database using id
		Student student1 = session.get(Student.class, id);

		tx.commit();
		return student1;
	}

	@Transactional
	public void save(Student student2) {

		Transaction tx = session.beginTransaction();

		// save student record into database
		session.saveOrUpdate(student2);
		tx.commit();
	}

	@Transactional
	public void deleteById(int id) {

		Transaction tx = session.beginTransaction();

		// get the book record from database and then delete the record
		Student student3 = session.get(Student.class, id);
		session.delete(student3);

		tx.commit();
	}

}
