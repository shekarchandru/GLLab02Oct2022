package com.gl.employees.employeesdebo.controller;


import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.AuthenticatedPrincipal;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.employees.employeesdebo.entity.Employee;
import com.gl.employees.employeesdebo.service.Employee_Repo_implementetion;

@Controller
@RequestMapping("Employees")
public class SpecialController {
	
	@Autowired
	private Employee_Repo_implementetion employee_Repo_implementetion;
	
	@GetMapping("/sayHello")
	public String greetAll(Model model)
	{
		model.addAttribute("greetings","Hello To All");
		return "hello";
	}
	@GetMapping("/List")
	public String FindallEmployeee(Model model) {
		System.out.println("In Controller list");
		List<Employee> employees = employee_Repo_implementetion.FeatchAllData();
		model.addAttribute("Employees", employees);
		return "Employee_List";
	}

	@GetMapping("/Form_Emp")
	public String AddEmployee(Model model) {

		Employee employee = new Employee();
		model.addAttribute("Employee", employee);
		return "Employee-form";
	}

	@PostMapping("/save")
	public String save(@ModelAttribute("Employee") Employee employee) {

		//CHANGED
		employee_Repo_implementetion.SaveEmployee(employee);
		return "redirect:/Employees/List/";

	}

	
	
	//CHANGED
	@RequestMapping("/Update")
	public String UpdateEmployee(@RequestParam("id") Long id,Model theModel) {

		//Optional<Employee> employee = this.employee_Repo_implementetion.FindById(id);
		Optional<Employee> employee = this.employee_Repo_implementetion.FindById(id);

		Employee employee2 = employee.get();
		employee2.setName(employee2.getName());
		employee2.setEmail(employee2.getEmail());
	

		this.employee_Repo_implementetion.SaveEmployee(employee2);
			// set Book as a model attribute to pre-populate the form
		theModel.addAttribute("Employee", employee2);

		// send over to our form
		return "Employee-form";	

	}
//CHANGED
	@RequestMapping("/Delete")
	public String DeleteEmployee(@RequestParam("id") Long id) {

		Optional<Employee> employee = employee_Repo_implementetion.FindById(id);
		System.out.println(employee);
		this.employee_Repo_implementetion.DeleteEmplyee(employee.get());
		return "redirect:/Employees/List/";
	}

	@GetMapping("/acsess-dined")
	public String DinaiedAcsees() {

		return "Acsees-Dinaied";
	}

}
