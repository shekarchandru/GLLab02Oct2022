package com.gl.crm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.crm.dao.CustomerDao;
import com.gl.crm.entity.Customer;


@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public String getData1() {
		// TODO Auto-generated method stub
		//return customerDao.getData();
		return "Hello";
	}

	public List<Customer> findAll() {
		return customerDao.getCustomers();
	}

	//@Transactional
	public Customer findById(int theId) {
		return customerDao.getCustomer(theId);
	}

	//@Transactional
	public void save(Customer theCustomer) {
		
		customerDao.saveCustomer(theCustomer);
		
	}

	//@Transactional
	public void deleteById(int theId) {
		
		customerDao.deleteCustomer(theId);
		
	}
}
