package com.CustomerRelationshipManagemanet.First.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.CustomerRelationshipManagemanet.First.Model.Customer;
@Service
public class CustomerService {
	// this is a variable Data store
	private Set <Customer> customers = new HashSet<>();

	public void addCustomer(Customer customer1) {
		System.out.println("Saving a Customer....");
		System.out.println(customers);
	//	Customer customer1 = new Customer(1,"Harish","Kumar","hari@gmail.com");
		this.customers.add(customer1);
	}

	public Set<Customer> fetchAllCustomer() {
		return this.customers;

	}

	public Customer fetchCustomerById(long customerId) {
		return this.customers
				.stream()
				.filter(customer -> customer.getId() == customerId)
				.findAny()
				.orElseThrow(
				() -> new IllegalArgumentException("Invalid CustomerId Is passed, Please enter the right one"));
	}

	public void deleteCustomerById(long customerId) {
		this.customers.removeIf(customer -> customer.getId() == customerId);
	}
	
	public void updateCustomer(long customerId,Customer customer)
	{
		Customer customerOld  =  fetchCustomerById(customerId);
		
		customerOld.setFirstName(customer.getFirstName());
		customerOld.setLastName(customer.getLastName());
		customerOld.setEmail(customer.getEmail());
	}

}
