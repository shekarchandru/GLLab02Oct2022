package com.gl.employees.employeesdebo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesdeboApplicationTests {

	@Test
	void contextLoads() {
	}

}
