package com.gl.stmgmt.DebnathProj.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

}
