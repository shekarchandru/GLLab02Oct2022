package com.CustomerRelationshipManagemanet.First.Model;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode

public class Customer {
	
	private long id;
	private String firstName;
	private String lastName;
	private String email;
	
	//Getters
	
	//ToString
	@Override
	public String toString() {
		return "Customer [id=" + id + ", FirstName=" + firstName + ", lastName=" + lastName + ", Email=" + email + "]";
	}
	
	
	//EqualsAndHashCode
	/*@Override
	public int hashCode() {
		return Objects.hash(email, firstName, lastName, id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(Email, other.Email) && Objects.equals(FirstName, other.FirstName)
				&& Objects.equals(LastName, other.LastName) && id == other.id;
	}*/
	//Constructors
/*	public Customer(long id, String firstName, String lastName, String email) {
		
		this.id = id;
		FirstName = firstName;
		LastName = lastName;
		Email = email;
	}
	public Customer() {
	
	}*/
	

}
